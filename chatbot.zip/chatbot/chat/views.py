from django.shortcuts import render,redirect
from django.http import HttpResponse, JsonResponse
from chat.forms import CustomUserForm
from .models import *
from django.contrib import messages
from django.contrib.auth import authenticate,login,logout
from rest_framework import authentication
from dotenv import load_dotenv
import os
from django.views import View
from django.utils.decorators import method_decorator
from django.views.decorators.csrf import csrf_exempt
import json
from .chat import get_pdf_text, get_text_chunks, get_vector_store, get_conversational_chain, userinput
from .models import *
# Create your views here.
    

# def home(request):
#     return render(request,"chat/main.html")

def sign_in(request):
    if request.method=="POST":
        name = request.POST.get("username")
        pwd = request.POST.get("Password")
        user = authenticate(request,username = name, password = pwd)
        if user is not None:
            login(request,user)
            messages.success(request, "{user} Logged in Successfully")
            return redirect("/chat")
        else:
            messages.error(request,"Invalid username or password")
            return redirect('/')
    return render(request,"chat/sign_in.html")


def register(request):
    form=CustomUserForm()
    if request.method=='POST':
        form=CustomUserForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request,"Registration Successful You can login now..!")
            return redirect('/chat')
    return render(request,"chat/register.html",{'form':form})

def log_out(request):
    if request.user.is_authenticated:
        logout(request)
        messages.success(request,"Logged out successfully...")
    return redirect('/')

def chat(request):
    messages.success(request,"Logged in successfully...")
    return render(request,"chat/ChatUI.html")

@method_decorator(csrf_exempt,name='dispatch')
class chatbot(View):
    # def bot_response(input):
    #         # documents=PDFDocument.objects.all()
    #         # print(documents)
    #         # if documents:
    #         #     all_responses=[]
    #         #     aggregated_text=""
    #         #     previous_response=None
    #         #     for Document in documents:
    #         #           pdf_docs=Document.document.path
    #         #           raw_text=get_pdf_text(pdf_docs)
    #         #           textchunks=get_text_chunks(raw_text)
    #         #           get_vector_store(textchunks)
    #         #           aggregated_text+=raw_text+"\n"
    #         #     try:
    #         #         all_chunks=get_text_chunks(aggregated_text)
    #         #         get_vector_store(all_chunks)
    #         #         response=userinput(user_input,previous_response)
    #         #         all_responses.append(response)
    #         #     except Exception as e:
    #         #          all_responses.append({"error": str(e)})
        
    #         all_responses="Hi there.. How are you? \n How can I help you?",input

    #         return all_responses
    
    async def post(Self, request):
            data=json.loads(request.body)
            global user_input
            user_input=data.get('userInput')
            if(user_input.lower() == "hi" or user_input.lower()=="" or user_input.lower()=="hello" or user_input.lower()==" "):
                bot_response="Hi there! I am AI integrated chatbot trained to custom subject knowledge. You can ask me question that I can able to answer if your question is in my knowledge base."
            else:
                bot_response=chat_response(user_input)
            
            
            # bot_response= "This is your Input: ",user_input

            return HttpResponse(bot_response)
    
def chat_response(user_input):
     pdf_docs="media/documents/Articles.pdf"
     pdf_text=get_pdf_text(pdf_docs) 
     chunks=get_text_chunks(pdf_text)
     get_vector_store(chunks)
     bot_response=userinput(user_input) 
     return bot_response
