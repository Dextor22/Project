from django.contrib import admin
from .models import PDFDocument

admin.site.register(PDFDocument)